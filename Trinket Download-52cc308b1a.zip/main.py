from turtle import *
import turtle

turtle.Screen().setup(700,700)

tur=turtle.Turtle()

tur.speed(0)
tur.up()
tur.color("white")
tur.fd(330)
tur.width(10)
tur.lt(90)
tur.down()
tur.circle(330)
tur.up()
tur.home()
tur.color("dark green")
tur.fd(320)
tur.width(10)
tur.lt(90)
tur.down()
tur.circle(320)
tur.up()
tur.home()
tur.color("lime")
tur.fd(310)
tur.width(10)
tur.lt(90)
tur.down()
tur.begin_fill()
tur.fillcolor("black")
tur.circle(310,360)

tur.end_fill()
tur.hideturtle()

#petals
def drawshape(turtle,radius):
  turtle.circle(radius,60)
  turtle.left(120)
  turtle.circle(radius,60)
  
list=["yellow","dark orange","orange red","red","maroon"]
def drawflo():
  for _ in range(5):
    petal=turtle.Turtle()
    petal.color(list[_%5])
    petal.begin_fill()
    petal.fillcolor(list[_%5])
    petal.speed(0)
    petal.pensize(1)
    no=15
    radius=300
    petal.left(_*43)
    for _ in range(no):
      drawshape(petal,radius)
      petal.left(360/no)
    petal.end_fill()
    petal.hideturtle()
    
drawflo()

turtle.done()

#illusion
t=turtle.Turtle()
list1=["white","yellow","gold","orange","red"]
t.speed(0)
for i in range(205):
  t.color(list1[i%5])
  t.pensize(20)
  t.forward(i)
  t.left(59)
t.up()
t.home()
t.width(21)
t.fd(208)
t.left(90)
t.color("indigo")
t.down()
t.circle(208,360,24)

t.up()
t.home()
t.width(15)
t.fd(195)
t.left(90)
t.color("light pink")
t.down()
t.circle(195,360,24)

t.up()
t.home()
t.width(10)
t.fd(202)
t.left(90)
t.color("magenta")
t.down()
t.circle(202,360,24)
t.up()

t.width(1)

#hexagon centre
t.home()
t.color("white")
t.fd(100)
t.left(90)
t.down()
t.begin_fill()
t.fillcolor("maroon")
t.circle(100,360,15)
t.end_fill()

t.up()
t.home()
t.width(1)
t.color("green")
t.fd(80)
t.left(90)
t.down()
t.begin_fill()
t.fillcolor("green")
t.circle(80,360,15)
t.end_fill()

t.up()
t.home()
t.color("maroon")
t.width(5)
t.fd(100)
t.left(90)
t.down()
t.circle(100,360,15)
t.up()


#flower
t.home()
t.down()
t.speed(0)
t.width(4)
t.color("yellow")
def leaf():
  t.speed(0)
  for up in range(24):
    t.fd(3)
    t.rt(3)
  for down in range(24):
    t.fd(1)
    t.lt(3)
    
  t.dot(15)
  t.rt(180)
  
  for up in range(24):
    t.fd(3)
    t.rt(3)
  for down in range(24):
    t.fd(1)
    t.lt(3)
  t.rt(180)
  t.lt(24)
    
t.lt(28)
t.begin_fill()
for i in range(15):
  leaf()
t.fillcolor("red")
t.end_fill()



t.hideturtle()
t.done()